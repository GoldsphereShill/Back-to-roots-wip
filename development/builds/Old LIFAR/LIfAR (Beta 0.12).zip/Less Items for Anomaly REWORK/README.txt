Less Items for Anomaly REWORK
Small mod that reduces amount of items while keeping all the features like crafting.
Version: 0.1 (beta)
Made by Chymo and Andermann 	- 2024
Special thanks to Great_Day for creation of the original Less Items mod


list of features: 
Simplified gun parts (reduced 3 tiers of barrels for rifles, pistols and shotguns separately, 3 tiers of triggers, metal, wooden and palstic parts)
Simplified suit parts (3 tiers of cloth, ballistic protection and teflon, some special suit liek Exoskeletons and seva suits include frames and helmets in theri parts)
Reduced amount of various kits to Universal gun kit, Universal suit repair kit, Exoskeleton repair kit and helmet repair kit
All various electronic parts combinedd into single item
Reduced upgrade kits to 3 tiers for guns and suits separartely to make them more viable option
Combined items that do the same thing into single one for each types (glues for example)
Removed excess items (plastic jars and such)
Adapted crafting for the new parts system

